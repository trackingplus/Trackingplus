// Mobile menu + year
const btn = document.querySelector('.menu-btn');
const nav = document.querySelector('.nav');
if (btn) {
  btn.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
}
document.getElementById('year').textContent = new Date().getFullYear();
