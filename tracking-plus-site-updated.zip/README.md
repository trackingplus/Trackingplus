# Tracking Plus — Website

Tailored single‑page site for **GPS tracking systems** and **dash/cabin camera** installation.

## Quick start
1. Edit `index.html` if you need to update service area or copy.
2. Replace images in `assets/` with real photos of your installs.
3. Deploy free with **GitHub Pages** or **Netlify** (drag‑and‑drop). The quote form works on Netlify automatically.

## Contact (live on site)
- Email: Trackingplus@cox.net
- Phone: 504-628-6900

## Platforms section
Currently listing: Mix-Powerfleet, Teletrac-Navman, Geotab, Zonar, Samsara, Netradyne, GPS Insite.
